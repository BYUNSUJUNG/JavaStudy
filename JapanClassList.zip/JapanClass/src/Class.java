
public class Class {

	public static void main(String[] args) {

		int month=3;
		int day=1;
		int aClass=99, bClass=100, cClass=101;
		String aTeacher="", bTeacher="",cTeacher="";

		while(day<32) {
			System.out.println(month+"��"+day+"��");
			if(day%7==2||day%7==3) {
				System.out.println("=====�ָ�=====");
			} else {
				
				if(aClass%3==0) aTeacher="��";
				else if(aClass%3==1) aTeacher="��";
				else aTeacher="��";
				
				if(bClass%3==0) bTeacher="��";
				else if(bClass%3==1) bTeacher="��";
				else bTeacher="��";
				
				if(cClass%3==0) cTeacher="��";
				else if(cClass%3==1) cTeacher="��";
				else cTeacher="��";
	
				System.out.println("A"+aTeacher+"B"+bTeacher+"C"+cTeacher);
				aClass--;
				bClass--;
				cClass--;

			}
			System.out.println("");
			day++;
		}
	}

}
